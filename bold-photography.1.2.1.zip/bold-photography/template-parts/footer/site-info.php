<?php
/**
 * The template used for displaying credits
 *
 * @package Bold_Photography
 */
?>

<?php
/**
 * bold_photography_credits hook
 * @hooked bold_photography_footer_content - 10
 */
do_action( 'bold_photography_credits' );
